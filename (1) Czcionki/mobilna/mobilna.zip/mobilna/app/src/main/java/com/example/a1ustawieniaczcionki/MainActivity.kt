package com.example.a1ustawieniaczcionki

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val sizeTextView: TextView = findViewById(R.id.size_textview)
        val alertTextView: TextView = findViewById(R.id.alert_textview)
        val sizeSeekBar: SeekBar = findViewById(R.id.size_seekbar)
        val confirmButton: Button = findViewById(R.id.confirm_button)

        confirmButton.setOnClickListener {
            if (sizeSeekBar.progress < 15) alertTextView.text = "Dzień dobry"
            else if (sizeSeekBar.progress < 30) alertTextView.text = "Good morning"
            else alertTextView.text = "Buenos dias"
        }

        sizeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                sizeTextView.text = "Rozmiar: $progress"
                alertTextView.textSize = progress.toFloat()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                Log.i("seekbar", "bite")
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                Log.i("seekbar", "bite")
            }

        })
    }
}