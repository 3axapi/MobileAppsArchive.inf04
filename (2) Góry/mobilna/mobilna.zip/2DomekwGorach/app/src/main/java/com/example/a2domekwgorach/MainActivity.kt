package com.example.a2domekwgorach

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        var likes: Int = 0;
        val LikesView: TextView = findViewById(R.id.likes_counter)
        val IncrementButton: Button = findViewById(R.id.increment_button)
        val DecrementButton: Button = findViewById(R.id.decrement_button)

        IncrementButton.setOnClickListener {
            likes++;
            LikesView.text = "$likes polubień"
        }

        DecrementButton.setOnClickListener {
            if (likes == 0) return@setOnClickListener
            else {
                likes--;
                LikesView.text = "$likes polubień"
            }
        }
    }
}