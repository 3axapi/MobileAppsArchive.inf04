﻿internal class Program
{
    static void Main()
    {
        List<int> list65 = new List<int>();
        Random random = new Random();

        for (int i = 0; i < 65; i++)
        {
            list65.Add(random.Next(0, 100));
        }
        
        try
        {
            Console.Write("Enter number (not other things): ");
            int number = int.Parse(Console.ReadLine());
            Console.WriteLine($"{GuardFilter(list65, number)}");
        }
        catch (FormatException)
        {
            Console.WriteLine("Wrong format");
        }
    }

    private static int GuardFilter(List<int> list, int value)
    {
        int i = 0;
        while (true)
        {
            if (i == list.Count)
            {
                Console.Write(">> There was not a specified number in the list. ");
                return 0;
            }
            
            if (list[i] == value)
            {
                Console.WriteLine($">> Element {value} has been found in the list.");
                Console.WriteLine(">> The list contains these elements:");
                for (int j = 0; j < list.Count; j++)
                {
                    Console.Write(list[j]);
                    if (list.Count-1 == j) break;
                    Console.Write(", ");
                }
                Console.Write("\n>> Position of specified number is: ");
                return i+1;
            }

            i++;
        }
    }
}